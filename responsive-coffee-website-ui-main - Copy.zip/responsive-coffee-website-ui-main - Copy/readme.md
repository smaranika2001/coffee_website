# Responsive Coffee Website using HTML CSS & JS

![preview img](/preview.jpg)
